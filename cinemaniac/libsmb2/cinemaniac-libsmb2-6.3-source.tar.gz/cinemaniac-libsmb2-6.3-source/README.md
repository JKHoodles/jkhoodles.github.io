# libsmb2 in CineManiac: source and build

CineManiac for iOS uses libsmb2 version 6.3 to play videos from SMB file sharing. The
library is licensed under the GNU Lesser General Public License version 2.1 or later; its
DCE/RPC parts under the BSD 2-Clause licence (see `COPYING`).

- `libsmb2-6.3.tar.gz`: the unmodified upstream source (SHA-256 5011003fd091513f897e1ebbb8e1a40af634386df7199716348b7f77569a2790),
  as downloaded from https://github.com/sahlberg/libsmb2. CineManiac applies no patches.
- `build-libsmb2.sh`: the exact script that compiles and packages the library. Kerberos
  (krb5-wrapper.c) is left out; the public headers' include paths are rewritten for
  framework packaging.
- `LIBSMB2_BUILD_INFO.md`: the version and toolchain used for the shipped build.

## Rebuilding

On a Mac with Xcode, put `build-libsmb2.sh` in a `Scripts/` folder and the tarball in
`Vendor/libsmb2/src/` next to it, then run `Scripts/build-libsmb2.sh`. It produces
`libsmb2.xcframework` (device and simulator, with debug symbols).

## Replacing the library

The library ships as a separate dynamic framework, `CineManiac.app/Frameworks/libsmb2.framework`,
loaded at run time through `@rpath`. A modified build with the same public interface can
replace it there; the app must then be re-signed to install it on a device.

Questions: contact the developer through the App Store listing's support link.
