# libsmb2 build used by CineManiac

- Version: 6.3
- Source: https://github.com/sahlberg/libsmb2/archive/refs/tags/libsmb2-6.3.tar.gz
- Source SHA-256: 5011003fd091513f897e1ebbb8e1a40af634386df7199716348b7f77569a2790
- Licence: GNU LGPL v2.1 or later (client library); BSD 2-Clause (DCE/RPC parts)
- Linking: dynamic framework, replaceable by the user (LGPL §6)
- Modifications to libsmb2 source: none (public headers' include paths rewritten for framework packaging)
- Left out: Kerberos (krb5-wrapper.c); logins use NTLMv2
- Build script: Scripts/build-libsmb2.sh in this repository
- Built: 2026-11-18T08:18:28Z with Xcode 27.2
