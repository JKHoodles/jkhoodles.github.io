#!/bin/bash
#
# build-libsmb2.sh — reproducible build of libsmb2 (SMB2/3 client) for CineManiac.
#
# Produces Packages/CineManiacKit/Frameworks/libsmb2.xcframework: one dynamic framework
# per platform (iOS device arm64 + iOS Simulator arm64), plus licence texts and a build
# manifest for Settings → Acknowledgements. See docs/adr/0017-smb-with-libsmb2.md.
#
# libsmb2's library (lib/, include/) is LGPL 2.1 or later; its DCE/RPC parts are BSD-2.
# Like FFmpeg it is linked dynamically so a user can replace it (LGPL §6). Kerberos is
# left out (NTLMv2 logins only), so no GSS code is linked.
#
# There is no CMake or autotools step: the library's sources are compiled directly with
# the SDK's clang, using the Apple config.h libsmb2 ships in include/apple.
#
# Usage:  Scripts/build-libsmb2.sh            # download (if needed), build, package
#         Scripts/build-libsmb2.sh --clean    # remove build products first

set -euo pipefail

# ---------------------------------------------------------------------------
# Pinned source
# ---------------------------------------------------------------------------
LIBSMB2_VERSION="6.3"
LIBSMB2_SHA256="5011003fd091513f897e1ebbb8e1a40af634386df7199716348b7f77569a2790"   # verified download, 2026-11-18
LIBSMB2_URL="https://github.com/sahlberg/libsmb2/archive/refs/tags/libsmb2-${LIBSMB2_VERSION}.tar.gz"

MIN_IOS="17.0"
NAME="libsmb2"

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
WORK="${ROOT}/Vendor/libsmb2"
SRC_DIR="${WORK}/src/libsmb2-libsmb2-${LIBSMB2_VERSION}"
BUILD_DIR="${WORK}/build"
OUT_DIR="${ROOT}/Packages/CineManiacKit/Frameworks"
LICENCE_DIR="${ROOT}/Packages/CineManiacKit/Sources/SettingsUI/Resources/Licences"

# The library proper; krb5-wrapper.c is left out (no Kerberos).
SOURCES=(aes.c aes128ccm.c alloc.c asn1-ber.c compat.c dcerpc.c dcerpc-lsa.c dcerpc-srvsvc.c errors.c
  init.c hmac.c hmac-md5.c libsmb2.c md4c.c md5.c ntlmssp.c pdu.c sha1.c sha224-256.c sha384-512.c
  smb2-cmd-close.c smb2-cmd-create.c smb2-cmd-echo.c smb2-cmd-error.c smb2-cmd-flush.c smb2-cmd-ioctl.c
  smb2-cmd-lock.c smb2-cmd-logoff.c smb2-cmd-negotiate.c smb2-cmd-notify-change.c smb2-cmd-oplock-break.c
  smb2-cmd-query-directory.c smb2-cmd-query-info.c smb2-cmd-read.c smb2-cmd-session-setup.c
  smb2-cmd-set-info.c smb2-cmd-tree-connect.c smb2-cmd-tree-disconnect.c smb2-cmd-write.c
  smb2-data-file-info.c smb2-data-filesystem-info.c smb2-data-security-descriptor.c
  smb2-data-reparse-point.c smb2-share-enum.c smb3-seal.c smb2-signing.c socket.c spnego-wrapper.c
  sync.c timestamps.c unicode.c usha.c)
# Public headers, copied flat into the framework.
HEADERS=(smb2.h smb2-errors.h libsmb2.h libsmb2-raw.h libsmb2-dcerpc.h libsmb2-dcerpc-srvsvc.h)

# ---------------------------------------------------------------------------
fetch_source() {
  mkdir -p "${WORK}/src"
  local tarball="${WORK}/src/libsmb2-${LIBSMB2_VERSION}.tar.gz"
  if [[ ! -f "$tarball" ]]; then
    echo "==> Downloading ${LIBSMB2_URL}"
    curl -fL --retry 3 -o "${tarball}.part" "$LIBSMB2_URL"
    mv "${tarball}.part" "$tarball"
  fi
  local actual; actual="$(shasum -a 256 "$tarball" | awk '{print $1}')"
  if [[ "$actual" != "$LIBSMB2_SHA256" ]]; then
    echo "error: SHA-256 mismatch for $tarball (expected $LIBSMB2_SHA256, got $actual)" >&2; exit 1
  fi
  echo "==> Source SHA-256: $actual"
  rm -rf "$SRC_DIR"
  tar -xzf "$tarball" -C "${WORK}/src"
  # Licence guard: the client library must still say LGPL 2.1 or later.
  grep -q "GNU Lesser General Public" "${SRC_DIR}/COPYING" \
    && grep -q "either version 2.1" "${SRC_DIR}/COPYING" \
    || { echo "error: libsmb2's COPYING no longer says LGPL 2.1+; review before shipping" >&2; exit 1; }
}

# build_platform <sdk> <version-min-flag> <name> <supported-platform>
build_platform() {
  local sdk="$1" minflag="$2" name="$3" platform="$4"
  local sysroot; sysroot="$(xcrun --sdk "$sdk" --show-sdk-path)"
  local cc; cc="$(xcrun --sdk "$sdk" -f clang)"
  local objdir="${BUILD_DIR}/${name}/obj"
  local fw="${BUILD_DIR}/${name}/${NAME}.framework"
  local flags=(-arch arm64 "${minflag}=${MIN_IOS}" -isysroot "$sysroot")
  rm -rf "$objdir" "$fw"; mkdir -p "$objdir" "$fw/Headers" "$fw/Modules"

  echo "==> Compiling for ${name}"
  local objects=()
  for src in "${SOURCES[@]}"; do
    local obj="${objdir}/${src%.c}.o"
    "$cc" "${flags[@]}" -c "${SRC_DIR}/lib/${src}" -o "$obj" \
      -O2 -g -fPIC -DHAVE_CONFIG_H -D_FILE_OFFSET_BITS=64 "-D_U_=__attribute__((unused))" \
      -I"${SRC_DIR}/include/apple" -I"${SRC_DIR}/include" -I"${SRC_DIR}/include/smb2" -I"${SRC_DIR}/lib" \
      -Wno-everything
    objects+=("$obj")
  done

  # Export exactly the symbols libsmb2 lists as its API.
  sed -e 's/^/_/' "${SRC_DIR}/lib/libsmb2.syms" > "${objdir}/exports.txt"
  "$cc" "${flags[@]}" -dynamiclib "${objects[@]}" -o "${fw}/${NAME}" \
    -install_name "@rpath/${NAME}.framework/${NAME}" \
    -exported_symbols_list "${objdir}/exports.txt" \
    -compatibility_version 1 -current_version "${LIBSMB2_VERSION}"

  # Headers: flat, with <smb2/x.h> rewritten to framework form <libsmb2/x.h>.
  for h in "${HEADERS[@]}"; do
    sed -e 's#<smb2/\([^>]*\)>#<libsmb2/\1>#g' "${SRC_DIR}/include/smb2/${h}" > "${fw}/Headers/${h}"
  done
  # libsmb2's headers expect the C standard types to be in scope already.
  cat > "${fw}/Headers/libsmb2-umbrella.h" <<UMBRELLA
#include <stdint.h>
#include <time.h>
#include <sys/types.h>
#include <sys/uio.h>
#include <libsmb2/smb2-errors.h>
#include <libsmb2/smb2.h>
#include <libsmb2/libsmb2.h>
#include <libsmb2/libsmb2-raw.h>
#include <libsmb2/libsmb2-dcerpc.h>
#include <libsmb2/libsmb2-dcerpc-srvsvc.h>
UMBRELLA
  cat > "${fw}/Modules/module.modulemap" <<MAP
framework module ${NAME} [extern_c] {
    umbrella header "libsmb2-umbrella.h"
    export *
}
MAP

  local dsym="${BUILD_DIR}/${name}/${NAME}.framework.dSYM"
  rm -rf "$dsym"
  xcrun dsymutil "${fw}/${NAME}" -o "$dsym"
  xcrun strip -x -S "${fw}/${NAME}"

  cat > "${fw}/Info.plist" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>CFBundleDevelopmentRegion</key><string>en</string>
  <key>CFBundleExecutable</key><string>${NAME}</string>
  <key>CFBundleIdentifier</key><string>au.com.hoodles.CineManiac.libsmb2</string>
  <key>CFBundleInfoDictionaryVersion</key><string>6.0</string>
  <key>CFBundleName</key><string>${NAME}</string>
  <key>CFBundlePackageType</key><string>FMWK</string>
  <key>CFBundleShortVersionString</key><string>${LIBSMB2_VERSION}</string>
  <key>CFBundleVersion</key><string>${LIBSMB2_VERSION}</string>
  <key>CFBundleSupportedPlatforms</key><array><string>${platform}</string></array>
  <key>MinimumOSVersion</key><string>${MIN_IOS}</string>
</dict>
</plist>
PLIST
}

write_manifest() {
  mkdir -p "$LICENCE_DIR"
  {
    echo "# libsmb2 build used by CineManiac"
    echo
    echo "- Version: ${LIBSMB2_VERSION}"
    echo "- Source: ${LIBSMB2_URL}"
    echo "- Source SHA-256: ${LIBSMB2_SHA256}"
    echo "- Licence: GNU LGPL v2.1 or later (client library); BSD 2-Clause (DCE/RPC parts)"
    echo "- Linking: dynamic framework, replaceable by the user (LGPL §6)"
    echo "- Modifications to libsmb2 source: none (public headers' include paths rewritten for framework packaging)"
    echo "- Left out: Kerberos (krb5-wrapper.c); logins use NTLMv2"
    echo "- Build script: Scripts/build-libsmb2.sh in this repository"
    echo "- Built: $(date -u +%Y-%m-%dT%H:%M:%SZ) with $(xcodebuild -version | head -1)"
  } > "${LICENCE_DIR}/LIBSMB2_BUILD_INFO.md"
  cp "${SRC_DIR}/LICENCE-LGPL-2.1.txt" "${LICENCE_DIR}/LIBSMB2_LICENSE_LGPLv2.1.txt"
  cp "${SRC_DIR}/COPYING" "${LICENCE_DIR}/LIBSMB2_COPYING.txt"
}

main() {
  if [[ "${1:-}" == "--clean" ]]; then rm -rf "$BUILD_DIR" "${OUT_DIR}/${NAME}.xcframework"; fi
  fetch_source
  build_platform iphoneos        -mios-version-min           ios           iPhoneOS
  build_platform iphonesimulator -mios-simulator-version-min ios-simulator iPhoneSimulator
  mkdir -p "$OUT_DIR"
  rm -rf "${OUT_DIR}/${NAME}.xcframework"
  xcodebuild -create-xcframework \
    -framework "${BUILD_DIR}/ios/${NAME}.framework" \
    -debug-symbols "${BUILD_DIR}/ios/${NAME}.framework.dSYM" \
    -framework "${BUILD_DIR}/ios-simulator/${NAME}.framework" \
    -debug-symbols "${BUILD_DIR}/ios-simulator/${NAME}.framework.dSYM" \
    -output "${OUT_DIR}/${NAME}.xcframework" > /dev/null
  write_manifest
  echo "==> ${OUT_DIR}/${NAME}.xcframework"
}

main "$@"
