#!/bin/bash
#
# build-ffmpeg.sh — reproducible, LGPL-only FFmpeg build for CineManiac.
#
# Produces one dynamic .xcframework per FFmpeg library (iOS device arm64 + iOS Simulator arm64)
# in Packages/CineManiacKit/Frameworks/, plus a licence/source manifest. See
# docs/DEPENDENCIES_AND_LICENSES.md §3 for why the libraries are dynamic and LGPL-only.
#
# Usage:  Scripts/build-ffmpeg.sh            # download (if needed), build, package
#         Scripts/build-ffmpeg.sh --clean    # remove build products first
#
# The decoder/demuxer/parser lists below are the single source of truth for what the
# app can play. Do not advertise anything that is not enabled here AND passes the
# Phase 7 media corpus.

set -euo pipefail

# ---------------------------------------------------------------------------
# Pinned source
# ---------------------------------------------------------------------------
FFMPEG_VERSION="9.0.2"
FFMPEG_SHA256="8c3850283eb25fa026482078a04051e0be17347b09ef81a0849bec15a96e002e"   # verified download of ffmpeg-9.0.2.tar.xz, 2026-11-16
FFMPEG_URL="https://ffmpeg.org/releases/ffmpeg-${FFMPEG_VERSION}.tar.xz"

MIN_IOS="17.0"
LIBS=(libavutil libswresample libswscale libavcodec libavformat)   # dependency order

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
WORK="${ROOT}/Vendor/FFmpeg"
SRC_DIR="${WORK}/src/ffmpeg-${FFMPEG_VERSION}"
BUILD_DIR="${WORK}/build"
OUT_DIR="${ROOT}/Packages/CineManiacKit/Frameworks"
# The manifest and licence are shown in the app (Settings → Acknowledgements), so they live in SettingsUI.
LICENCE_DIR="${ROOT}/Packages/CineManiacKit/Sources/SettingsUI/Resources/Licences"
JOBS="$(sysctl -n hw.ncpu)"

# ---------------------------------------------------------------------------
# Component whitelist
# ---------------------------------------------------------------------------
# FFmpeg's own Dolby (ac3, eac3, truehd, mlp) and DTS (dca) decoders are intentionally
# absent until legal review (decision Q5). Their parsers stay enabled so tracks are
# still identified.
#
# Decision Q9: AC-3 and E-AC-3 are decoded by Apple's AudioToolbox instead, through
# FFmpeg's thin "ac3_at" / "eac3_at" wrappers. The decoding itself happens in the OS
# (which Apple licenses); no Dolby decoder code is compiled into these libraries.
# There is no Apple DTS decoder, so DTS stays undecodable.
VIDEO_DECODERS="h264 hevc mpeg1video mpeg2video mpeg4 h263 msmpeg4v1 msmpeg4v2 msmpeg4v3
  wmv1 wmv2 wmv3 vc1 vp6 vp6a vp6f vp8 vp9 av1 rv30 rv40 flv theora mjpeg prores"
AUDIO_DECODERS="aac aac_latm mp1 mp1float mp2 mp2float mp3 mp3float opus vorbis flac alac
  pcm_s16le pcm_s16be pcm_s24le pcm_s24be pcm_s32le pcm_f32le pcm_u8 pcm_alaw pcm_mulaw
  pcm_dvd pcm_bluray adpcm_ms adpcm_ima_wav wmav1 wmav2 wmapro cook"
SYSTEM_AUDIO_DECODERS="ac3_at eac3_at"
SUBTITLE_DECODERS="subrip srt ass ssa movtext webvtt text dvdsub pgssub dvbsub"
# ac3/eac3: bare Dolby audio files (Step 7.6). Demuxers only frame the stream; decoding is
# still AudioToolbox's (ac3_at/eac3_at), so FFmpeg's own Dolby decoders stay out (Q5).
DEMUXERS="mov matroska avi mpegps mpegts mpegvideo flv asf ogg rm mp3 aac ac3 eac3 flac wav h264 hevc m4v"
PARSERS="h264 hevc mpeg4video mpegvideo h263 vc1 vp8 vp9 av1 mjpeg aac aac_latm mpegaudio
  opus vorbis flac ac3 dca mlp cook dvdsub dvbsub"
HWACCELS="h264_videotoolbox hevc_videotoolbox mpeg1_videotoolbox mpeg2_videotoolbox
  mpeg4_videotoolbox h263_videotoolbox prores_videotoolbox vp9_videotoolbox av1_videotoolbox"

join() { local IFS=,; echo "$*"; }

COMMON_FLAGS=(
  --enable-cross-compile --target-os=darwin --arch=aarch64
  --enable-shared --disable-static --enable-pic --install-name-dir=@rpath
  # Debug information is kept for dSYMs (crash symbolication); the frameworks are stripped
  # to their exported symbols after the dSYMs are made, as --enable-stripping did before.
  --disable-programs --disable-doc --enable-debug --enable-optimizations --disable-stripping
  --disable-autodetect --enable-videotoolbox --enable-audiotoolbox --enable-zlib --enable-iconv
  --extra-libs=-liconv   # Apple ships iconv in libiconv, not libc; used for subtitle charset conversion
  --disable-network --disable-avdevice --disable-avfilter
  --disable-everything
  --enable-avcodec --enable-avformat --enable-avutil --enable-swresample --enable-swscale
  --enable-protocol=file
  --enable-decoder="$(join ${VIDEO_DECODERS} ${AUDIO_DECODERS} ${SYSTEM_AUDIO_DECODERS} ${SUBTITLE_DECODERS})"
  --enable-demuxer="$(join ${DEMUXERS})"
  --enable-parser="$(join ${PARSERS})"
  --enable-hwaccel="$(join ${HWACCELS})"
)

# Licence guard: this project ships LGPL 2.1+ only.
for flag in "${COMMON_FLAGS[@]}"; do
  case "$flag" in
    --enable-gpl|--enable-nonfree|--enable-version3) echo "error: $flag is forbidden (LGPL-only build)" >&2; exit 1 ;;
  esac
done

# ---------------------------------------------------------------------------
fetch_source() {
  mkdir -p "${WORK}/src"
  local tarball="${WORK}/src/ffmpeg-${FFMPEG_VERSION}.tar.xz"
  if [[ ! -f "$tarball" ]]; then
    echo "==> Downloading ${FFMPEG_URL}"
    curl -fL --retry 3 -o "${tarball}.part" "$FFMPEG_URL"
    mv "${tarball}.part" "$tarball"
  fi
  local actual; actual="$(shasum -a 256 "$tarball" | awk '{print $1}')"
  if [[ -n "$FFMPEG_SHA256" && "$actual" != "$FFMPEG_SHA256" ]]; then
    echo "error: SHA-256 mismatch for $tarball (expected $FFMPEG_SHA256, got $actual)" >&2; exit 1
  fi
  echo "==> Source SHA-256: $actual"
  SOURCE_SHA256="$actual"
  if [[ ! -d "$SRC_DIR" ]]; then
    tar -xf "$tarball" -C "${WORK}/src"
  fi
}

# build_platform <sdk> <version-min-flag> <name>
build_platform() {
  local sdk="$1" minflag="$2" name="$3"
  local sysroot; sysroot="$(xcrun --sdk "$sdk" --show-sdk-path)"
  local cc; cc="$(xcrun --sdk "$sdk" -f clang)"
  local prefix="${BUILD_DIR}/${name}/install"
  local objdir="${BUILD_DIR}/${name}/obj"
  local cflags="-arch arm64 ${minflag}=${MIN_IOS} -isysroot ${sysroot}"

  echo "==> Configuring for ${name}"
  rm -rf "$objdir"; mkdir -p "$objdir" "$prefix"
  ( cd "$objdir"
    "${SRC_DIR}/configure" --prefix="$prefix" --cc="$cc" --sysroot="$sysroot" \
      --extra-cflags="$cflags" --extra-ldflags="$cflags" \
      "${COMMON_FLAGS[@]}" > configure.log 2>&1 || { tail -40 configure.log; exit 1; }
    # configure silently ignores an unknown name inside a comma list (it only warns when a
    # whole list matches nothing), so check every whitelisted component individually.
    # Names are configure's, which can differ from the codec name (mov_text -> movtext).
    local missing=0
    check_enabled() {
      local kind="$1"; shift
      for n in "$@"; do
        local flag="CONFIG_$(echo "${n}_${kind}" | tr '[:lower:]' '[:upper:]')"
        grep -q "#define ${flag} 1" config_components.h || { echo "error: ${kind} '${n}' is not enabled (unknown name?)" >&2; missing=1; }
      done
    }
    check_enabled decoder ${VIDEO_DECODERS} ${AUDIO_DECODERS} ${SYSTEM_AUDIO_DECODERS} ${SUBTITLE_DECODERS}
    check_enabled demuxer ${DEMUXERS}
    check_enabled parser ${PARSERS}
    check_enabled hwaccel ${HWACCELS}
    [ "$missing" = 0 ] || exit 1
    for guard in CONFIG_GPL CONFIG_NONFREE CONFIG_VERSION3; do
      grep -q "#define ${guard} 0" config.h || { echo "error: ${guard} is enabled" >&2; exit 1; }
    done
    for required in CONFIG_VIDEOTOOLBOX CONFIG_AUDIOTOOLBOX CONFIG_AC3_AT_DECODER CONFIG_EAC3_AT_DECODER; do
      grep -qh "#define ${required} 1" config.h config_components.h || { echo "error: ${required} not enabled" >&2; exit 1; }
    done
    for absent in CONFIG_AC3_DECODER CONFIG_AC3_FIXED_DECODER CONFIG_EAC3_DECODER CONFIG_TRUEHD_DECODER CONFIG_MLP_DECODER CONFIG_DCA_DECODER; do
      grep -qh "#define ${absent} 0" config.h config_components.h || { echo "error: ${absent} must stay disabled (Q5)" >&2; exit 1; }
    done
    echo "==> Building ${name} (${JOBS} jobs)"
    make -j"$JOBS" > build.log 2>&1 || { tail -40 build.log; exit 1; }
    make install > install.log 2>&1
    cp configure.log "${BUILD_DIR}/${name}/configure.log"
  )
}

# make_framework <platform-name> <lib> <supported-platform>
make_framework() {
  local name="$1" lib="$2" platform="$3"
  local prefix="${BUILD_DIR}/${name}/install"
  local fw="${BUILD_DIR}/${name}/frameworks/${lib}.framework"
  rm -rf "$fw"; mkdir -p "$fw/Headers"

  local dylib; dylib="$(ls "${prefix}/lib/${lib}".*.dylib | grep -E "${lib}\.[0-9]+\.dylib$" | head -1)"
  cp "$dylib" "${fw}/${lib}"
  cp -R "${prefix}/include/${lib}/." "${fw}/Headers/"

  # Rewrite install names: @rpath/libavutil.NN.dylib -> @rpath/libavutil.framework/libavutil
  install_name_tool -id "@rpath/${lib}.framework/${lib}" "${fw}/${lib}"
  for dep in "${LIBS[@]}"; do
    local old; old="$(otool -L "${fw}/${lib}" | awk '{print $1}' | grep -E "^@rpath/${dep}\.[0-9]+\.dylib$" || true)"
    [[ -n "$old" ]] && install_name_tool -change "$old" "@rpath/${dep}.framework/${dep}" "${fw}/${lib}"
  done

  # dSYM from the unstripped library (its debug map points at the object files in obj/),
  # then strip local and debug symbols; the UUID is unchanged, so the dSYM matches.
  local dsym="${BUILD_DIR}/${name}/frameworks/${lib}.framework.dSYM"
  rm -rf "$dsym"
  xcrun dsymutil "${fw}/${lib}" -o "$dsym"
  xcrun strip -x -S "${fw}/${lib}"
  local fw_uuid dsym_uuid
  fw_uuid="$(xcrun dwarfdump --uuid "${fw}/${lib}" | awk '{print $2}')"
  dsym_uuid="$(xcrun dwarfdump --uuid "$dsym" | awk '{print $2}')"
  [[ "$fw_uuid" == "$dsym_uuid" ]] || { echo "error: ${lib} dSYM UUID ${dsym_uuid} != ${fw_uuid}" >&2; exit 1; }

  local version; version="$(basename "$dylib" | sed -E "s/${lib}\.([0-9]+)\.dylib/\1/")"
  cat > "${fw}/Info.plist" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>CFBundleDevelopmentRegion</key><string>en</string>
  <key>CFBundleExecutable</key><string>${lib}</string>
  <key>CFBundleIdentifier</key><string>au.com.hoodles.CineManiac.ffmpeg.${lib}</string>
  <key>CFBundleInfoDictionaryVersion</key><string>6.0</string>
  <key>CFBundleName</key><string>${lib}</string>
  <key>CFBundlePackageType</key><string>FMWK</string>
  <key>CFBundleShortVersionString</key><string>${FFMPEG_VERSION}</string>
  <key>CFBundleVersion</key><string>${version}</string>
  <key>CFBundleSupportedPlatforms</key><array><string>${platform}</string></array>
  <key>MinimumOSVersion</key><string>${MIN_IOS}</string>
</dict>
</plist>
PLIST
}

write_manifest() {
  local manifest="${LICENCE_DIR}/FFMPEG_BUILD_INFO.md"
  mkdir -p "$LICENCE_DIR"
  {
    echo "# FFmpeg build used by CineManiac"
    echo
    echo "- Version: ${FFMPEG_VERSION}"
    echo "- Source: ${FFMPEG_URL}"
    echo "- Source SHA-256: ${SOURCE_SHA256}"
    echo "- Licence: GNU LGPL v2.1 or later (no GPL, nonfree or version3 components)"
    echo "- Linking: dynamic frameworks, replaceable by the user (LGPL §6)"
    echo "- Modifications to FFmpeg source: none"
    echo "- Build script: Scripts/build-ffmpeg.sh in this repository"
    echo "- Built: $(date -u +%Y-%m-%dT%H:%M:%SZ) with $(xcodebuild -version | head -1)"
    echo
    echo "## Configure flags (both platforms, plus --cc/--sysroot/--extra-cflags per platform)"
    echo
    echo '```'
    printf '%s\n' "${COMMON_FLAGS[@]}"
    echo '```'
  } > "$manifest"
  cp "${SRC_DIR}/COPYING.LGPLv2.1" "${LICENCE_DIR}/FFMPEG_LICENSE_LGPLv2.1.txt"
}

main() {
  if [[ "${1:-}" == "--clean" ]]; then rm -rf "$BUILD_DIR" "$OUT_DIR"; fi
  fetch_source
  build_platform iphoneos         -mios-version-min           ios
  build_platform iphonesimulator  -mios-simulator-version-min ios-simulator

  mkdir -p "$OUT_DIR"
  for lib in "${LIBS[@]}"; do
    make_framework ios           "$lib" iPhoneOS
    make_framework ios-simulator "$lib" iPhoneSimulator
    rm -rf "${OUT_DIR}/${lib}.xcframework"
    # Each slice carries its dSYM, so Xcode copies it into archives and App Store Connect
    # can symbolicate crashes inside FFmpeg.
    xcodebuild -create-xcframework \
      -framework "${BUILD_DIR}/ios/frameworks/${lib}.framework" \
      -debug-symbols "${BUILD_DIR}/ios/frameworks/${lib}.framework.dSYM" \
      -framework "${BUILD_DIR}/ios-simulator/frameworks/${lib}.framework" \
      -debug-symbols "${BUILD_DIR}/ios-simulator/frameworks/${lib}.framework.dSYM" \
      -output "${OUT_DIR}/${lib}.xcframework" > /dev/null
    echo "==> ${OUT_DIR}/${lib}.xcframework"
  done
  write_manifest
  echo "==> Done. Manifest: ${LICENCE_DIR}/FFMPEG_BUILD_INFO.md"
}

main "$@"
