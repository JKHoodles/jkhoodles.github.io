# FFmpeg build used by CineManiac

- Version: 9.0.2
- Source: https://ffmpeg.org/releases/ffmpeg-9.0.2.tar.xz
- Source SHA-256: 8c3850283eb25fa026482078a04051e0be17347b09ef81a0849bec15a96e002e
- Licence: GNU LGPL v2.1 or later (no GPL, nonfree or version3 components)
- Linking: dynamic frameworks, replaceable by the user (LGPL §6)
- Modifications to FFmpeg source: none
- Build script: Scripts/build-ffmpeg.sh in this repository
- Built: 2026-11-17T11:05:24Z with Xcode 27.2

## Configure flags (both platforms, plus --cc/--sysroot/--extra-cflags per platform)

```
--enable-cross-compile
--target-os=darwin
--arch=aarch64
--enable-shared
--disable-static
--enable-pic
--install-name-dir=@rpath
--disable-programs
--disable-doc
--enable-debug
--enable-optimizations
--disable-stripping
--disable-autodetect
--enable-videotoolbox
--enable-audiotoolbox
--enable-zlib
--enable-iconv
--extra-libs=-liconv
--disable-network
--disable-avdevice
--disable-avfilter
--disable-everything
--enable-avcodec
--enable-avformat
--enable-avutil
--enable-swresample
--enable-swscale
--enable-protocol=file
--enable-decoder=h264,hevc,mpeg1video,mpeg2video,mpeg4,h263,msmpeg4v1,msmpeg4v2,msmpeg4v3,wmv1,wmv2,wmv3,vc1,vp6,vp6a,vp6f,vp8,vp9,av1,rv30,rv40,flv,theora,mjpeg,prores,aac,aac_latm,mp1,mp1float,mp2,mp2float,mp3,mp3float,opus,vorbis,flac,alac,pcm_s16le,pcm_s16be,pcm_s24le,pcm_s24be,pcm_s32le,pcm_f32le,pcm_u8,pcm_alaw,pcm_mulaw,pcm_dvd,pcm_bluray,adpcm_ms,adpcm_ima_wav,wmav1,wmav2,wmapro,cook,ac3_at,eac3_at,subrip,srt,ass,ssa,movtext,webvtt,text,dvdsub,pgssub,dvbsub
--enable-demuxer=mov,matroska,avi,mpegps,mpegts,mpegvideo,flv,asf,ogg,rm,mp3,aac,ac3,eac3,flac,wav,h264,hevc,m4v
--enable-parser=h264,hevc,mpeg4video,mpegvideo,h263,vc1,vp8,vp9,av1,mjpeg,aac,aac_latm,mpegaudio,opus,vorbis,flac,ac3,dca,mlp,cook,dvdsub,dvbsub
--enable-hwaccel=h264_videotoolbox,hevc_videotoolbox,mpeg1_videotoolbox,mpeg2_videotoolbox,mpeg4_videotoolbox,h263_videotoolbox,prores_videotoolbox,vp9_videotoolbox,av1_videotoolbox
```
