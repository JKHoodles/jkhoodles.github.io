# FFmpeg in CineManiac: source and build

CineManiac for iOS uses the FFmpeg libraries libavutil, libswresample, libswscale, libavcodec
and libavformat, version 9.0.2, under the GNU Lesser General Public License version 2.1
or later. No GPL, nonfree or version-3 components are enabled.

- `ffmpeg-9.0.2.tar.xz`: the unmodified upstream source (SHA-256 8c3850283eb25fa026482078a04051e0be17347b09ef81a0849bec15a96e002e),
  as downloaded from https://ffmpeg.org/releases/. CineManiac applies no patches.
- `build-ffmpeg.sh`: the exact script that configures and builds the libraries.
- `FFMPEG_BUILD_INFO.md`: the configure flags and the toolchain used for the shipped build.
- `COPYING.LGPLv2.1`: the licence.

## Rebuilding

On a Mac with Xcode, put `build-ffmpeg.sh` in a `Scripts/` folder and the tarball in
`Vendor/FFmpeg/src/` next to it, then run `Scripts/build-ffmpeg.sh`. It produces one dynamic
`.xcframework` per library (device and simulator, with debug symbols).

## Replacing the libraries

The libraries ship as separate dynamic frameworks inside `CineManiac.app/Frameworks/`
(`libavcodec.framework`, etc.), loaded at run time through `@rpath`. A modified build with the
same public interface can replace them there; the app must then be re-signed to install it on
a device, as for any iOS app.

Questions: contact the developer through the App Store listing's support link.
